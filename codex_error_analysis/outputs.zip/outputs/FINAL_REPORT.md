# BERTA / FRIDA hard FP-FN audit

Classified audit assignments: **400**; unique source pairs: **379**.

## Primary-class mix

| focal_model | error_type | audit_primary_class | n | share_within_model_error |
| --- | --- | --- | --- | --- |
| berta | FN | likely_label_issue | 85 | 0.8500 |
| berta | FN | ambiguous_business_rule | 9 | 0.0900 |
| berta | FN | semantic_or_alias_failure | 3 | 0.0300 |
| berta | FN | missing_information | 2 | 0.0200 |
| berta | FN | variant_policy_failure | 1 | 0.0100 |
| berta | FP | likely_label_issue | 72 | 0.7200 |
| berta | FP | critical_attribute_mismatch | 12 | 0.1200 |
| berta | FP | missing_information | 6 | 0.0600 |
| berta | FP | ambiguous_business_rule | 5 | 0.0500 |
| berta | FP | truncation_related | 5 | 0.0500 |
| frida | FN | likely_label_issue | 81 | 0.8100 |
| frida | FN | ambiguous_business_rule | 12 | 0.1200 |
| frida | FN | missing_information | 4 | 0.0400 |
| frida | FN | semantic_or_alias_failure | 2 | 0.0200 |
| frida | FN | variant_policy_failure | 1 | 0.0100 |
| frida | FP | likely_label_issue | 61 | 0.6100 |
| frida | FP | critical_attribute_mismatch | 13 | 0.1300 |
| frida | FP | truncation_related | 10 | 0.1000 |
| frida | FP | missing_information | 9 | 0.0900 |
| frida | FP | ambiguous_business_rule | 7 | 0.0700 |


## Severity-band trends

| focal_model | error_type | severity_band | n | label_issue_rate | ambiguous_rate | model_failure_rate | truncation_rate | critical_attribute_rate | other_model_correct_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| berta | FN | ultra_hard_1_50 | 25 | 0.9600 | 0.0400 | 0.0000 | 0.0000 | 0.0000 | 0.0400 |
| berta | FN | very_hard_51_150 | 25 | 0.8800 | 0.0800 | 0.0400 | 0.0000 | 0.0000 | 0.0000 |
| berta | FN | hard_151_400 | 25 | 0.8800 | 0.0800 | 0.0400 | 0.0000 | 0.0000 | 0.0000 |
| berta | FN | moderate_hard_401_1000 | 25 | 0.6800 | 0.1600 | 0.0800 | 0.0000 | 0.0000 | 0.0800 |
| berta | FP | ultra_hard_1_50 | 25 | 0.9200 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FP | very_hard_51_150 | 25 | 0.7200 | 0.1200 | 0.1200 | 0.0400 | 0.0800 | 0.0000 |
| berta | FP | hard_151_400 | 25 | 0.8400 | 0.0000 | 0.0800 | 0.0400 | 0.0400 | 0.0400 |
| berta | FP | moderate_hard_401_1000 | 25 | 0.4000 | 0.0800 | 0.4800 | 0.1200 | 0.3600 | 0.0800 |
| frida | FN | ultra_hard_1_50 | 25 | 0.8800 | 0.0800 | 0.0400 | 0.0000 | 0.0000 | 0.0000 |
| frida | FN | very_hard_51_150 | 25 | 0.9200 | 0.0400 | 0.0000 | 0.0000 | 0.0000 | 0.0400 |
| frida | FN | hard_151_400 | 25 | 0.8400 | 0.1200 | 0.0400 | 0.0000 | 0.0000 | 0.0800 |
| frida | FN | moderate_hard_401_1000 | 25 | 0.6000 | 0.2400 | 0.0400 | 0.0000 | 0.0000 | 0.0400 |
| frida | FP | ultra_hard_1_50 | 25 | 0.8000 | 0.0000 | 0.1200 | 0.0800 | 0.0400 | 0.0400 |
| frida | FP | very_hard_51_150 | 25 | 0.7600 | 0.0000 | 0.2000 | 0.1200 | 0.0800 | 0.0000 |
| frida | FP | hard_151_400 | 25 | 0.5200 | 0.1600 | 0.2400 | 0.0800 | 0.1600 | 0.0000 |
| frida | FP | moderate_hard_401_1000 | 25 | 0.3600 | 0.1200 | 0.3600 | 0.1200 | 0.2400 | 0.0800 |


## User hypothesis: label issues vs depth

| focal_model | error_type | first_band_label_issue_rate | last_band_label_issue_rate | delta_last_minus_first | monotone_nonincreasing | interpretation |
| --- | --- | --- | --- | --- | --- | --- |
| berta | FN | 0.9600 | 0.6800 | -0.2800 | True | supports_user_hypothesis |
| berta | FP | 0.9200 | 0.4000 | -0.5200 | False | supports_user_hypothesis |
| frida | FN | 0.8800 | 0.6000 | -0.2800 | False | supports_user_hypothesis |
| frida | FP | 0.8000 | 0.3600 | -0.4400 | True | supports_user_hypothesis |


## Most frequent secondary subtypes

| focal_model | error_type | audit_secondary_subtype | n |
| --- | --- | --- | --- |
| berta | FN | model_number | 15 |
| berta | FN | size_dimension | 14 |
| berta | FN | brand | 10 |
| berta | FN | product_type | 10 |
| berta | FN | article_sku | 9 |
| berta | FN | color | 9 |
| berta | FN | flavor_scent | 7 |
| berta | FN | compatibility | 6 |
| berta | FN | missing_attribute | 4 |
| berta | FN | purpose | 3 |
| berta | FN | formulation | 2 |
| berta | FN | quantity | 2 |
| berta | FN | tire_parameter | 2 |
| berta | FN | volume_weight | 2 |
| berta | FN | alias_synonym | 1 |
| berta | FN | annotation_inconsistency | 1 |
| berta | FN | material | 1 |
| berta | FN | other_numeric | 1 |
| berta | FN | pack_count | 1 |
| berta | FP | near_exact_duplicate | 65 |
| berta | FP | model_number | 10 |
| berta | FP | missing_attribute | 5 |
| berta | FP | brand | 4 |
| berta | FP | pack_count | 4 |
| berta | FP | quantity | 3 |
| berta | FP | pair_budget_truncation | 2 |
| berta | FP | purpose | 2 |
| berta | FP | flavor_scent | 1 |
| berta | FP | other_numeric | 1 |
| berta | FP | set_completeness | 1 |
| berta | FP | size_dimension | 1 |
| berta | FP | tire_parameter | 1 |
| frida | FN | product_type | 19 |
| frida | FN | compatibility | 17 |
| frida | FN | article_sku | 11 |
| frida | FN | model_number | 11 |
| frida | FN | color | 6 |
| frida | FN | flavor_scent | 6 |
| frida | FN | size_dimension | 6 |
| frida | FN | missing_attribute | 4 |
| frida | FN | annotation_inconsistency | 3 |
| frida | FN | brand | 3 |
| frida | FN | formulation | 3 |
| frida | FN | alias_synonym | 2 |
| frida | FN | purpose | 2 |
| frida | FN | volume_weight | 2 |
| frida | FN | generation_version | 1 |
| frida | FN | material | 1 |
| frida | FN | other_numeric | 1 |
| frida | FN | set_completeness | 1 |
| frida | FN | tire_parameter | 1 |
| frida | FP | near_exact_duplicate | 56 |
| frida | FP | brand | 6 |
| frida | FP | pack_count | 6 |
| frida | FP | article_sku | 5 |
| frida | FP | missing_attribute | 4 |
| frida | FP | model_number | 4 |
| frida | FP | color | 3 |
| frida | FP | volume_weight | 3 |
| frida | FP | pair_budget_truncation | 2 |


## Categories with highest audited model-failure rate

| focal_model | error_type | category | n | label_issue_rate | model_failure_rate | truncation_rate | critical_attribute_rate |
| --- | --- | --- | --- | --- | --- | --- | --- |
| berta | FN | Галантерея и аксессуары | 4 | 0.2500 | 0.2500 | 0.0000 | 0.0000 |
| berta | FN | Хобби и творчество | 4 | 0.5000 | 0.2500 | 0.0000 | 0.0000 |
| berta | FN | Одежда | 8 | 0.7500 | 0.1250 | 0.0000 | 0.0000 |
| berta | FN | Бытовая техника | 11 | 0.9091 | 0.0909 | 0.0000 | 0.0000 |
| berta | FN | Автотовары | 24 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FN | Бытовая химия | 2 | 0.5000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FN | Дом и сад | 1 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FN | Канцелярские товары | 2 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FN | Красота и гигиена | 6 | 0.8333 | 0.0000 | 0.0000 | 0.0000 |
| berta | FN | Мебель | 2 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FN | Музыкальные инструменты | 1 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FN | Обувь | 4 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FN | Продукты питания | 8 | 0.7500 | 0.0000 | 0.0000 | 0.0000 |
| berta | FN | Спорт и отдых | 8 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FN | Строительство и ремонт | 2 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FN | Товары для животных | 4 | 0.5000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FN | Электроника | 4 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FN | Ювелирные изделия | 5 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FP | Автотовары | 2 | 0.0000 | 0.5000 | 0.5000 | 0.0000 |
| berta | FP | Продукты питания | 5 | 0.6000 | 0.4000 | 0.4000 | 0.0000 |
| berta | FP | Бытовая химия | 9 | 0.6667 | 0.3333 | 0.1111 | 0.2222 |
| berta | FP | Канцелярские товары | 7 | 0.7143 | 0.2857 | 0.0000 | 0.2857 |
| berta | FP | Галантерея и аксессуары | 4 | 0.2500 | 0.2500 | 0.0000 | 0.2500 |
| berta | FP | Строительство и ремонт | 5 | 0.8000 | 0.2000 | 0.0000 | 0.2000 |
| berta | FP | Спорт и отдых | 6 | 0.6667 | 0.1667 | 0.0000 | 0.1667 |
| berta | FP | Хобби и творчество | 12 | 0.7500 | 0.1667 | 0.0000 | 0.1667 |
| berta | FP | Бытовая техника | 7 | 0.8571 | 0.1429 | 0.0000 | 0.1429 |
| berta | FP | Товары для животных | 15 | 0.7333 | 0.1333 | 0.0667 | 0.0667 |
| berta | FP | Детские товары | 12 | 0.6667 | 0.0833 | 0.0000 | 0.0833 |
| berta | FP | Аптека | 2 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FP | Дом и сад | 3 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FP | Красота и гигиена | 6 | 0.8333 | 0.0000 | 0.0000 | 0.0000 |
| berta | FP | Мебель | 1 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FP | Музыкальные инструменты | 3 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| berta | FP | Электроника | 1 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| frida | FN | Строительство и ремонт | 1 | 0.0000 | 1.0000 | 0.0000 | 0.0000 |
| frida | FN | Продукты питания | 5 | 0.6000 | 0.2000 | 0.0000 | 0.0000 |
| frida | FN | Красота и гигиена | 7 | 0.5714 | 0.1429 | 0.0000 | 0.0000 |
| frida | FN | Автотовары | 29 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| frida | FN | Аптека | 1 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| frida | FN | Бытовая техника | 6 | 0.8333 | 0.0000 | 0.0000 | 0.0000 |
| frida | FN | Бытовая химия | 5 | 0.8000 | 0.0000 | 0.0000 | 0.0000 |
| frida | FN | Галантерея и аксессуары | 2 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| frida | FN | Дом и сад | 3 | 0.3333 | 0.0000 | 0.0000 | 0.0000 |
| frida | FN | Канцелярские товары | 6 | 0.6667 | 0.0000 | 0.0000 | 0.0000 |
| frida | FN | Мебель | 1 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| frida | FN | Музыкальные инструменты | 4 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| frida | FN | Обувь | 3 | 0.3333 | 0.0000 | 0.0000 | 0.0000 |
| frida | FN | Спорт и отдых | 12 | 0.8333 | 0.0000 | 0.0000 | 0.0000 |
| frida | FN | Товары для животных | 4 | 0.7500 | 0.0000 | 0.0000 | 0.0000 |
| frida | FN | Хобби и творчество | 2 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| frida | FN | Электроника | 3 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| frida | FN | Ювелирные изделия | 6 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| frida | FP | Ювелирные изделия | 1 | 0.0000 | 1.0000 | 1.0000 | 0.0000 |
| frida | FP | Аптека | 3 | 0.3333 | 0.6667 | 0.0000 | 0.6667 |
| frida | FP | Автотовары | 6 | 0.3333 | 0.5000 | 0.1667 | 0.3333 |
| frida | FP | Строительство и ремонт | 9 | 0.4444 | 0.4444 | 0.2222 | 0.2222 |
| frida | FP | Электроника | 9 | 0.3333 | 0.4444 | 0.1111 | 0.3333 |
| frida | FP | Продукты питания | 11 | 0.3636 | 0.3636 | 0.2727 | 0.0909 |
| frida | FP | Дом и сад | 4 | 0.7500 | 0.2500 | 0.2500 | 0.0000 |
| frida | FP | Хобби и творчество | 4 | 0.7500 | 0.2500 | 0.0000 | 0.2500 |
| frida | FP | Детские товары | 7 | 0.8571 | 0.1429 | 0.0000 | 0.1429 |
| frida | FP | Товары для животных | 9 | 0.5556 | 0.1111 | 0.0000 | 0.1111 |
| frida | FP | Бытовая химия | 10 | 0.7000 | 0.1000 | 0.1000 | 0.0000 |
| frida | FP | Бытовая техника | 5 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| frida | FP | Галантерея и аксессуары | 1 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| frida | FP | Канцелярские товары | 3 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| frida | FP | Красота и гигиена | 4 | 0.5000 | 0.0000 | 0.0000 | 0.0000 |
| frida | FP | Мебель | 1 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| frida | FP | Музыкальные инструменты | 4 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| frida | FP | Спорт и отдых | 9 | 0.8889 | 0.0000 | 0.0000 | 0.0000 |


## Manual review

Cases queued for manual review: **64**. See `manual_review_queue.html`.


## Main-agent conclusions

### Что реально происходит

В выборке из 400 audit assignments (379 уникальных пар) доминируют не настоящие ошибки моделей, а проблемы target/policy: **299/400 (74,75%)** классифицированы как `likely_label_issue`, ещё **33/400 (8,25%)** — как `ambiguous_business_rule`. `missing_information` составляет **21/400 (5,25%)**. На подтверждённые model failures остаётся **47/400 (11,75%)**. Это стратифицированная выборка по 25 примеров на model × error type × severity band, поэтому эти доли нельзя напрямую переносить на весь поток ошибок.

### BERTA

У BERTA подтверждено **21/200 (10,5%)** реальных ошибок: 17 FP и 4 FN. Реальные FP — прежде всего пропуск видимых различий бренда, количества/комплектности, модели/артикула и назначения. Пять FP связаны с causal truncation: чаще длинные составы или pair budget вытесняют количество/размерный вариант. Реальные FN редки и в основном похожи на semantic/alias failures при бедной карточке или пропущенном атрибуте; один случай относится к color-variant policy.

### FRIDA

У FRIDA подтверждено **26/200 (13,0%)** реальных ошибок: 23 FP и 3 FN. Для FP повторяются бренд, model/article suffix, оптические и другие числовые параметры, generation/version и назначение товара. FRIDA чаще BERTA страдает от causal truncation: **10 FP** против 5 у BERTA, особенно по pack count. Реальные FN также редки: два alias/semantic случая и один color-variant case.

### Label/business-rule issues и глубина ranking

Гипотеза о снижении label issues дальше от top hard errors поддерживается по направлению во всех четырёх группах: BERTA FN **96% → 68%**, BERTA FP **92% → 40%**, FRIDA FN **88% → 60%**, FRIDA FP **80% → 36%** от band 1 к band 4. Строгая монотонность есть только у BERTA FN и FRIDA FP: у BERTA FP наблюдается отскок **72% → 84%** в band 3, у FRIDA FN — **88% → 92%** в band 2. Поэтому вывод — сильный first-vs-last trend, но не универсальная монотонная зависимость.

### Насколько causal truncation

После full-original vs focal-visible review causal truncation подтверждён для **15/400 (3,75%)** assignments, и все они относятся к FP. Это не главный источник hard errors в целом, но заметная часть подтверждённых model failures: **15/47 (31,9%)**; для реальных FP — **5/17 (29,4%)** у BERTA и **10/23 (43,5%)** у FRIDA. Один первоначальный truncation case был переклассифицирован: различие кода светильника `W` vs `W-B` уже было видно FRIDA, поэтому causal claim был неверен.

### Recurring subtypes для следующих экспериментов

1. Pack count и quantity: явные `1/2/3 шт.` и количества, потерянные после длинных атрибутов.
2. Brand/manufacturer mismatch у визуально почти одинаковых generic/compatible товаров.
3. Model number и article/SKU suffix: короткие числовые и буквенные отличия.
4. Purpose/compatibility: назначение корма, автосовместимость, тип применения.
5. Alias/synonym и missing-attribute FN на бедных карточках.
6. Color/variant policy, где важно отделять реальный variant от неизвестного business rule.
7. Optical и другие numeric parameters: знак оптической силы, размеры, вес/объём.
8. Generation/version distinctions вроде базовой модели против `...2`.
9. Pair-budget truncation после длинных составов/списков OEM, особенно у FRIDA.

### Required manual review

Главный агент лично просмотрел все **288** `likely_label_issue` с confidence ≥ 0,90, все **15** `truncation_related` с confidence ≥ 0,85, единственный case с confidence < 0,70 и все **32** `critical_attribute_mismatch` (то есть больше требуемой случайной десятки). Исправлено 9 audit assignments: один ложный causal truncation и восемь переуверенных critical mismatches/дубликатов, где отсутствующий атрибут, shipping weight, неполный цвет или слабое размерное различие не доказывали отдельный SKU. После правок batch validation снова прошла **400/400**.
